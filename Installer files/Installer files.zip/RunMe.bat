@echo off
PowerShell -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
pause